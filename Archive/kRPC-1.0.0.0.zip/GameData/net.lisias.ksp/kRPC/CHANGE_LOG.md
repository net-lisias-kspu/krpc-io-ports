# kRPC.IO.Ports /L Unleashed :: Change Log

* 2025-0917: 1.0.0.0 (lisias) for KSP >= 1.2
    + Initial (and probably last) release. Not to be directly consumed by the public.
* 2017-0919: 1.0.0 (djungelorm)
	+ Changes, wrt to the Mono implementation:
		- Disable SetSignal calls as they do not play well with socat
		- Disable TryBaudRate call as it is not available within KSP
